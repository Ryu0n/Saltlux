package Ex04;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import Ex01.Ex01;
import Ex02.Ex02;
import Ex03.Ex03;

import Functions.CosineSimiliarity.*;
import Functions.Sorter.rankSorter;

public class Ex04 {

	public static void main(String[] args) {
		CSbaseTFIDF();
	}
	
	
	// 1~7
	public static HashMap<String, HashMap<String, Double>> CSbaseTFIDF() {
		// TF-IDF score per doc
		Scanner sc = new Scanner(System.in);
		System.out.print("���ϸ��� �Է��� �ּ���. : ");
		String doc_name = sc.next();
		
//		Ex01 e1 = new Ex01(); // TF-IDF setter
		Ex01.set_vecList();
		CosineSimiliarity cs = new CosineSimiliarity(); // Cosine Similiarity
		
		HashMap<String, HashMap<String, Double>> vecList = Ex01.get_vecList(); // ��� ���Ͽ� ���� ���ĺ� �� TF-IDF Score
		HashMap<String, HashMap<String, Double>> CS = cs.cosineSimilarity(vecList); // Calculate base on TF-IDF
		
		ArrayList<String> keyList = rankSorter.sortHSbyValue_double(CS.get(doc_name));
		for(String key : keyList){
			System.out.print(key + " : ");
			System.out.println(CS.get(doc_name).get(key));
		}
		
		return CS;
	}
	
	// 1~7
	public static HashMap<String, Double> CSbaseTFIDF_1(String file_name) {
		// TF-IDF score per doc
		
//		Ex01 e1 = new Ex01(); // TF-IDF setter
		Ex01.set_vecList_1();
		CosineSimiliarity cs = new CosineSimiliarity(); // Cosine Similiarity
		
		HashMap<String, HashMap<String, Double>> vecList = Ex01.get_vecList(); // ��� ���Ͽ� ���� ���ĺ� �� TF-IDF Score
		HashMap<String, HashMap<String, Double>> CS = cs.cosineSimilarity(vecList); // Calculate base on TF-IDF
		
		return CS.get(file_name);
	}
	
	// 8~10
	public static HashMap<String, Double> CSbaseTFIDF_2(String file_name) {
		// TF-IDF score per doc
		
		Ex01 e1 = new Ex01(file_name); // TF-IDF setter
		e1.set_vecList_2();
		CosineSimiliarity cs = new CosineSimiliarity(); // Cosine Similiarity
		
		HashMap<String, HashMap<String, Double>> vecList = e1.get_vecList(); // ��� ���Ͽ� ���� ���ĺ� �� TF-IDF Score
		HashMap<String, HashMap<String, Double>> CS = cs.cosineSimilarity(vecList); // Calculate base on TF-IDF
		
		return CS.get(file_name);
	}
	
	// 1~10
	public static HashMap<String, Double> CSbaseTFIDF_3(String file_name) {
		// TF-IDF score per doc
		
//		Ex01 e1 = new Ex01(file_name); // TF-IDF setter
		Ex01.set_vecList_3();
		CosineSimiliarity cs = new CosineSimiliarity(); // Cosine Similiarity
		
		HashMap<String, HashMap<String, Double>> vecList = Ex01.get_vecList(); // ��� ���Ͽ� ���� ���ĺ� �� TF-IDF Score
		HashMap<String, HashMap<String, Double>> CS = cs.cosineSimilarity(vecList); // Calculate base on TF-IDF
		
		return CS.get(file_name);
	}
}
