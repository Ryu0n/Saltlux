package Ex01;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.Scanner;

import Functions.TF_IDF.cal_TFIDF;
import Functions.fileGetter.Getter;
import Functions.fileGetter.Reader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;;

public class Ex01 {
	
	// Encapsulation
	private static HashMap<String, HashMap<String, Double>> vecList;
	
	// getter
	public static HashMap<String, HashMap<String, Double>> get_vecList(){
		return vecList;
	}
	
	
	
	// for Ex04 - 1~7
	public static void set_vecList() {
		Getter getter = new Getter();
		Reader reader = new Reader();
		
		File[] fileList = getter.get_file();
		HashSet<String> keyList = new HashSet<>();
		
		for(File file: fileList) {
			ArrayList<String> dish = reader.reading_str(file);
			for(String s:dish) {
				keyList.add(s);
			}	
		}
			
		vecList = execute_4(keyList); // setter
//		System.out.println(vecList);
	}
	
	// for Ex05-04 - 1~7
	public static void set_vecList_1() {
		Getter getter = new Getter();
		Reader reader = new Reader();
		
		File[] fileList = getter.get_file();
		HashSet<String> keyList = new HashSet<>();
		
		for(File file: fileList) {
			ArrayList<String> dish = reader.reading_str(file);
			for(String s:dish) {
				keyList.add(s);
			}	
		}
			
		vecList = execute_5_1(keyList); // setter
//		System.out.println(vecList);
	}
	
	// for Ex05-04 - 8~10
	public static void set_vecList_2() {
		Getter getter = new Getter();
		Reader reader = new Reader();
		
		File[] fileList = getter.get_file2();
		HashSet<String> keyList = new HashSet<>();
		
		for(File file: fileList) {
			ArrayList<String> dish = reader.reading_str(file);
			for(String s:dish) {
				keyList.add(s);
			}	
		}
			
		vecList = execute_5_2(keyList); // setter
//		System.out.println(vecList);
	}

	// for Ex05-03 Cosine Similarity - 1~10
	public static void set_vecList_3() {
		Getter getter = new Getter();
		Reader reader = new Reader();
		
		File[] fileList = getter.conbine();
		HashSet<String> keyList = new HashSet<>();
		
		for(File file: fileList) {
			ArrayList<String> dish = reader.reading_str(file);
			for(String s:dish) {
				keyList.add(s);
			}	
		}
			
		vecList = execute_5_3(keyList); // setter
//		System.out.println(vecList);
	}
	
	
	
	
	public Ex01(String input_ch) {
		execute(input_ch);
	}

	
	
	public Ex01() {
		// TODO Auto-generated constructor stub
	}



	public static void main(String[] args) {
		execute();
	}
	
	
	
	// for Ex01
	public static void execute() {
		Scanner sc = new Scanner(System.in); // ��ĳ�� ��ü ���� �� ���۷��� ��ȯ
		System.out.print("���� �Է� : ");
		char input_ch = sc.next().charAt(0); // ���� �Է�
		
		Getter getter = new Getter();
		Reader reader = new Reader();
		cal_TFIDF cal = new cal_TFIDF();
		
		File[] fileList = getter.get_file(); // ���� ���۷��� ��ȯ
		
		int in_counter = 0; // ���ڰ� ���Ե� ������ ��
		int num_files = fileList.length; // ��ü ���� ��
		
		// to save file's TF value
		ArrayList<Double> TF_list = new ArrayList<>();
		
		for (File file: fileList) { // �� ���� ��ȸ
			ArrayList<Character> file_detail = reader.reading(file);
			//get-TF
			double TF = cal.get_TF(input_ch, file_detail);
			TF_list.add(TF);
			
			// for IDF parameter
			if(file_detail.contains(input_ch)) {
				in_counter++;
			}
		}
		
		// get-IDF
		double IDF = cal.get_IDF(in_counter, num_files);
//		System.out.print("IDF : ");
//		System.out.println(IDF);
		
		// TF-IDF
		for (double TF: TF_list) {
			System.out.print("TF-IDF : ");
			System.out.println(TF*IDF);
		}
	}
	
	// for Ex04 (1~7)
	public static HashMap<String, HashMap<String, Double>> execute_4(HashSet<String> keyList) {
		Getter getter = new Getter();
		Reader reader = new Reader();
		cal_TFIDF cal = new cal_TFIDF();
		
		HashMap<String, HashMap<String, Double>> big_hash = new HashMap<>();
		
		for (String c: keyList) {
//			System.out.println("CURR_CHAR IS : "+c);
			File[] fileList = getter.get_file(); // ���� ���۷��� ��ȯ (1~7)
			
			int in_counter = 0; // ���ڰ� ���Ե� ������ ��
			int num_files = fileList.length; // ��ü ���� ��
			
			// to save file's TF value
			ArrayList<Double> TF_list = new ArrayList<>();
			
			for (File file: fileList) { // �� ���� ��ȸ
				ArrayList<String> file_detail = reader.reading_str(file);
				//get-TF
				double TF = cal.get_TF(c, file_detail);
				TF_list.add(TF);
				
				// for IDF parameter
				if(file_detail.contains(c)) {
					in_counter++;
				}
			}
			
			// get-IDF
			double IDF = cal.get_IDF(in_counter, num_files);
//			System.out.print("IDF : ");
//			System.out.println(IDF);
			
			
			int f_cnt = 0; 
			HashMap<String, Double> sm_hash = new HashMap<>();

			// TF-IDF
			for (double TF: TF_list) { // �ϳ��� ���ڿ� ���� ���Ϻ��� ��� sm_hash
				if(big_hash.get(fileList[f_cnt].getName())==null) {
					sm_hash = new HashMap<>();
				} else {
					sm_hash = big_hash.get(fileList[f_cnt].getName());
				}
				
				sm_hash.put(c, TF*IDF);
//				System.out.print("This is..");
//				System.out.println(sm_hash);
				big_hash.put(fileList[f_cnt].getName(), sm_hash);
				f_cnt++;
			}
		}
//		System.out.println(big_hash);
		return big_hash;
	}
	
	// for Ex05-01 TF-IDF (1~10)
	public static void execute(String input_ch) {
		Getter getter = new Getter();
		Reader reader = new Reader();
		cal_TFIDF cal = new cal_TFIDF();
		
		File[] fileList = getter.conbine();

		int in_counter = 0; // ���ڰ� ���Ե� ������ ��
		int num_files = fileList.length; // ��ü ���� ��
		
		// to save file's TF value
		ArrayList<Double> TF_list = new ArrayList<>();
		
		for (File file: fileList) { // �� ���� ��ȸ
			ArrayList<String> file_detail = reader.reading_str(file);
			//get-TF
			double TF = cal.get_TF(input_ch, file_detail);
			TF_list.add(TF);
			
			// for IDF parameter
			if(file_detail.contains(input_ch)) {
				in_counter++;
//				System.out.println(in_counter);
			}
		}
		
		// get-IDF
		double IDF = cal.get_IDF(in_counter, num_files);
//		System.out.print("IDF : ");
//		System.out.println(IDF);
		
		// TF-IDF
		for (double TF: TF_list) {
			System.out.print("TF-IDF : ");
			System.out.println(TF*IDF);
		}
	}
	
	// for Ex05-03 Cosine Similarity - 1~10
	public static HashMap<String, HashMap<String, Double>> execute_5_3(HashSet<String> keyList) {
		Getter getter = new Getter();
		Reader reader = new Reader();
		cal_TFIDF cal = new cal_TFIDF();
		
		HashMap<String, HashMap<String, Double>> big_hash = new HashMap<>();
		
		for (String c: keyList) {
//			System.out.println("CURR_CHAR IS : "+c);
			File[] fileList = getter.conbine(); // ���� ���۷��� ��ȯ (1~7)
			
			int in_counter = 0; // ���ڰ� ���Ե� ������ ��
			int num_files = fileList.length; // ��ü ���� ��
			
			// to save file's TF value
			ArrayList<Double> TF_list = new ArrayList<>();
			
			for (File file: fileList) { // �� ���� ��ȸ
				ArrayList<String> file_detail = reader.reading_str(file);
				//get-TF
				double TF = cal.get_TF(c, file_detail);
				TF_list.add(TF);
				
				// for IDF parameter
				if(file_detail.contains(c)) {
					in_counter++;
				}
			}
			
			// get-IDF
			double IDF = cal.get_IDF(in_counter, num_files);
//			System.out.print("IDF : ");
//			System.out.println(IDF);
			
			int f_cnt = 0; 
			HashMap<String, Double> sm_hash = new HashMap<>();

			// TF-IDF
			for (double TF: TF_list) { // �ϳ��� ���ڿ� ���� ���Ϻ��� ��� sm_hash
				if(big_hash.get(fileList[f_cnt].getName())==null) {
					sm_hash = new HashMap<>();
				} else {
					sm_hash = big_hash.get(fileList[f_cnt].getName());
				}
				
				sm_hash.put(c, TF*IDF);
//				System.out.print("This is..");
//				System.out.println(sm_hash);
				big_hash.put(fileList[f_cnt].getName(), sm_hash);
				f_cnt++;
			}
		}
//		System.out.println(big_hash);
		return big_hash;
	}	
	
	// for Ex05-04 (1~7 or 8~10) TF-IDF
	public static void execute(String input_ch, int path) {
		Getter getter = new Getter();
		Reader reader = new Reader();
		cal_TFIDF cal = new cal_TFIDF();
		
		File[] fileList = null;
		if(path==1)
			fileList = getter.get_file();
		else if(path==2)
			fileList = getter.get_file2();

		int in_counter = 0; // ���ڰ� ���Ե� ������ ��
		int num_files = fileList.length; // ��ü ���� ��
		
		// to save file's TF value
		ArrayList<Double> TF_list = new ArrayList<>();
		
		for (File file: fileList) { // �� ���� ��ȸ
			ArrayList<String> file_detail = reader.reading_str(file);
			//get-TF
			double TF = cal.get_TF(input_ch, file_detail);
			TF_list.add(TF);
			
			// for IDF parameter
			if(file_detail.contains(input_ch)) {
				in_counter++;
			}
		}
		
		// get-IDF
		double IDF = cal.get_IDF(in_counter, num_files);
//		System.out.print("IDF : ");
//		System.out.println(IDF);
		
		// TF-IDF
		for (double TF: TF_list) {
			System.out.print("TF-IDF : ");
			System.out.println(TF*IDF);
		}
	}
	
	// for Ex05-04 (1~7) Cosine
		public static HashMap<String, HashMap<String, Double>> execute_5_1(HashSet<String> keyList) {
			Getter getter = new Getter();
			Reader reader = new Reader();
			cal_TFIDF cal = new cal_TFIDF();
			
			HashMap<String, HashMap<String, Double>> big_hash = new HashMap<>();
			
			for (String c: keyList) {
//				System.out.println("CURR_CHAR IS : "+c);
				File[] fileList = getter.get_file(); // ���� ���۷��� ��ȯ (1~7)
				
				int in_counter = 0; // ���ڰ� ���Ե� ������ ��
				int num_files = fileList.length; // ��ü ���� ��
				
				// to save file's TF value
				ArrayList<Double> TF_list = new ArrayList<>();
				
				for (File file: fileList) { // �� ���� ��ȸ
					ArrayList<String> file_detail = reader.reading_str(file);
					//get-TF
					double TF = cal.get_TF(c, file_detail);
					TF_list.add(TF);
					
					// for IDF parameter
					if(file_detail.contains(c)) {
						in_counter++;
					}
				}
				
				// get-IDF
				double IDF = cal.get_IDF(in_counter, num_files);
//				System.out.print("IDF : ");
//				System.out.println(IDF);
				
				
				int f_cnt = 0; 
				HashMap<String, Double> sm_hash = new HashMap<>();

				// TF-IDF
				for (double TF: TF_list) { // �ϳ��� ���ڿ� ���� ���Ϻ��� ��� sm_hash
					if(big_hash.get(fileList[f_cnt].getName())==null) {
						sm_hash = new HashMap<>();
					} else {
						sm_hash = big_hash.get(fileList[f_cnt].getName());
					}
					
					sm_hash.put(c, TF*IDF);
//					System.out.print("This is..");
//					System.out.println(sm_hash);
					big_hash.put(fileList[f_cnt].getName(), sm_hash);
					f_cnt++;
				}
			}
//			System.out.println(big_hash);
			return big_hash;
		}
	
	// for Ex05-04 (8~10) Cosine
		public static HashMap<String, HashMap<String, Double>> execute_5_2(HashSet<String> keyList) {
			Getter getter = new Getter();
			Reader reader = new Reader();
			cal_TFIDF cal = new cal_TFIDF();
			
			HashMap<String, HashMap<String, Double>> big_hash = new HashMap<>();
			
			for (String c: keyList) {
//				System.out.println("CURR_CHAR IS : "+c);
				File[] fileList = getter.get_file2(); // ���� ���۷��� ��ȯ (8~10)
				
				int in_counter = 0; // ���ڰ� ���Ե� ������ ��
				int num_files = fileList.length; // ��ü ���� ��
				
				// to save file's TF value
				ArrayList<Double> TF_list = new ArrayList<>();
				
				for (File file: fileList) { // �� ���� ��ȸ
					ArrayList<String> file_detail = reader.reading_str(file);
					//get-TF
					double TF = cal.get_TF(c, file_detail);
					TF_list.add(TF);
					
					// for IDF parameter
					if(file_detail.contains(c)) {
						in_counter++;
					}
				}
				
				// get-IDF
				double IDF = cal.get_IDF(in_counter, num_files);
//				System.out.print("IDF : ");
//				System.out.println(IDF);
				
				
				int f_cnt = 0; 
				HashMap<String, Double> sm_hash = new HashMap<>();

				// TF-IDF
				for (double TF: TF_list) { // �ϳ��� ���ڿ� ���� ���Ϻ��� ��� sm_hash
					if(big_hash.get(fileList[f_cnt].getName())==null) {
						sm_hash = new HashMap<>();
					} else {
						sm_hash = big_hash.get(fileList[f_cnt].getName());
					}
					
					sm_hash.put(c, TF*IDF);
//					System.out.print("This is..");
//					System.out.println(sm_hash);
					big_hash.put(fileList[f_cnt].getName(), sm_hash);
					f_cnt++;
				}
			}
//			System.out.println(big_hash);
			return big_hash;
		}	
		

}
