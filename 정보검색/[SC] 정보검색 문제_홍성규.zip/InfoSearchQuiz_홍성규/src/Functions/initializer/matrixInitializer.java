package Functions.initializer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class matrixInitializer {
	// for Character matrix
	public static HashMap<Character, HashMap<Character, Integer>> initialize_matrix(int window_size, ArrayList<Character> file_detail){
		HashMap<Character, HashMap<Character, Integer>> empty = new HashMap<>();
		
		
		System.out.println("matrix initializing..");
		HashSet<Character> withoutDuplicate = new HashSet<>();
		for(char data : file_detail){
			withoutDuplicate.add(data);
		}
//		System.out.println(withoutDuplicate);
		
		Iterator it1 = withoutDuplicate.iterator();
		
		// zero-base initialize
		while(it1.hasNext()) {
			char alphabet1 = (char)it1.next();
			Iterator it2 = withoutDuplicate.iterator();
			HashMap<Character, Integer> small_hash = new HashMap<>();
			while(it2.hasNext()){
				char alphabet2 = (char)it2.next();
				small_hash.put(alphabet2, 0);
			}			
			empty.put(alphabet1, small_hash);
		}
		
		// counter
		for(int i=0; i<file_detail.size(); i++) {
			for(int j=0; j<file_detail.size(); j++) {
				if(i!=j && Math.abs(i-j)<=window_size) { // �Ÿ��� window_size ������ ���
					HashMap<Character, Integer> small_hash = empty.get(file_detail.get(i));
					small_hash.put(file_detail.get(j), small_hash.get(file_detail.get(j))+1);
					empty.put(file_detail.get(i), small_hash);
				}
			}
		}
//		System.out.println(empty);
		
		return empty;
	}
	
	// for String matrix
	public static HashMap<String, HashMap<String, Integer>> initialize_str_matrix(int window_size, ArrayList<String> file_detail){
		HashMap<String, HashMap<String, Integer>> empty = new HashMap<>();
		
		
		System.out.println("matrix initializing..");
		HashSet<String> withoutDuplicate = new HashSet<>();
		for(String data : file_detail){
			withoutDuplicate.add(data);
		}
//		System.out.println(withoutDuplicate);
		
		Iterator it1 = withoutDuplicate.iterator();
		
		// zero-base initialize
		while(it1.hasNext()) {
			String alphabet1 = (String)it1.next();
			Iterator it2 = withoutDuplicate.iterator();
			HashMap<String, Integer> small_hash = new HashMap<>();
			while(it2.hasNext()){
				String alphabet2 = (String)it2.next();
				small_hash.put(alphabet2, 0);
			}			
			empty.put(alphabet1, small_hash);
		}
		
		// counter
		for(int i=0; i<file_detail.size(); i++) {
			for(int j=0; j<file_detail.size(); j++) {
				if(i!=j && Math.abs(i-j)<=window_size) { // �Ÿ��� window_size ������ ���
					HashMap<String, Integer> small_hash = empty.get(file_detail.get(i));
					small_hash.put(file_detail.get(j), small_hash.get(file_detail.get(j))+1);
					empty.put(file_detail.get(i), small_hash);
				}
			}
		}
//		System.out.println(empty);
		
		return empty;
	}
}
