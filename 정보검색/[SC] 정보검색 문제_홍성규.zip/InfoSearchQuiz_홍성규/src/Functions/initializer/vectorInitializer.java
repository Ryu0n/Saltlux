package Functions.initializer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class vectorInitializer {
	public static HashSet<String> withoutDuplicate(ArrayList<String> file_detail){
		HashSet<String> hs = new HashSet<>();
		for (String data: file_detail) {
			hs.add(data);
		}
		return hs;
	}
	
	// for Character vectors
	public static HashMap<Character, Integer> initializeVec(ArrayList<Character> file_detail){
		HashMap<Character, Integer> hm = new HashMap<>();
						
		for (char data: file_detail) {
//			hm.put(data, hm.get(data)+1);
			hm.put(data, 1);
		}
//		System.out.println(hm);
		
		return hm;
	}
	
	// for String vectors
	public static HashMap<String, Double> initializeVec_str(ArrayList<String> file_detail){
		HashMap<String, Double> hm = new HashMap<>();
						
		for (String data: file_detail) {
//			hm.put(data, hm.get(data)+1);
			hm.put(data, 1.0);
		}
//		System.out.println(hm);
		
		return hm;
	}
}
