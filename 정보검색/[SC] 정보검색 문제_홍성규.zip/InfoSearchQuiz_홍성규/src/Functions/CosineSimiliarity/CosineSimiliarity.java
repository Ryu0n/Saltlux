package Functions.CosineSimiliarity;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import Functions.Sorter.rankSorter;

public class CosineSimiliarity {
	public static ArrayList<HashMap<String, Double>> unionVec(HashMap<String, Double> vector_1, HashMap<String, Double> vector_2){
		ArrayList<HashMap<String, Double>> unionVectors = new ArrayList<HashMap<String, Double>>();
		
		Set<String> keyList = new HashSet<String>();
		
		Set<String> keyList1 = vector_1.keySet();
		Set<String> keyList2 = vector_2.keySet();
		
		for(String key:keyList1)
			keyList.add(key);
		
		for(String key:keyList2)
			keyList.add(key);
		
		
		for(String key:keyList) {
			if(!vector_1.containsKey(key))
				vector_1.put(key, 0.0);
			if(!vector_2.containsKey(key))
				vector_2.put(key, 0.0);
		}
		
		unionVectors.add(vector_1);
		unionVectors.add(vector_2);
			
		return unionVectors;
	}
	
	// union base on TFIDF vectors
	public static ArrayList<HashMap<String, Double>> unionVec_TFIDF(HashMap<String, Double> vector_1, HashMap<String, Double> vector_2){
		ArrayList<HashMap<String, Double>> unionVectors = new ArrayList<HashMap<String, Double>>();
		
		Set<String> keyList = new HashSet<String>();
		
		Set<String> keyList1 = vector_1.keySet();
		Set<String> keyList2 = vector_2.keySet();
		
		for(String key:keyList1)
			keyList.add(key);
		
		for(String key:keyList2)
			keyList.add(key);
		
		
		for(String key:keyList) {
			if(!vector_1.containsKey(key))
				vector_1.put(key, 0.0);
			if(!vector_2.containsKey(key))
				vector_2.put(key, 0.0);
		}
		
		unionVectors.add(vector_1);
		unionVectors.add(vector_2);
			
		return unionVectors;
	}
	
	
	
	public static HashMap<String, HashMap<String, Double>> cosineSimilarity(File[] fileList, ArrayList<HashMap<String, Double>> vectorList) {
		HashMap<String, HashMap<String, Double>> cs = new HashMap<>();
		
		for (int i=0; i<fileList.length; i++) {
			HashMap<String, Double> cs_i = new HashMap<>();
			for (int j=0; j<fileList.length; j++) {
				HashMap<String, Double> vector_1 = vectorList.get(i);
				HashMap<String, Double> vector_2 = vectorList.get(j);
				
				vector_1 = unionVec(vector_1, vector_2).get(0);
				vector_2 = unionVec(vector_1, vector_2).get(1);
				
				System.out.println(vector_1);
				System.out.println(vector_1);
				
				Set<String> keyList = vector_1.keySet();

				double sigma0=0.0; double sigma1=0.0; double sigma2=0.0;
				for (String key: keyList) {
					sigma0 += vector_1.get(key) * vector_2.get(key);
					sigma1 += Math.pow(vector_1.get(key), 2);
					sigma2 += Math.pow(vector_2.get(key), 2);
				}
				sigma1 = Math.sqrt(sigma1);
				sigma2 = Math.sqrt(sigma2);
				double answer = sigma0 / (sigma1*sigma2);
				
				cs_i.put(fileList[j].getName(), answer);
			}
			cs.put(fileList[i].getName(),cs_i);
		}
		
		return cs;
	}
	
	// Calculate base on TF-IDF
	public static HashMap<String, HashMap<String, Double>> cosineSimilarity(HashMap<String, HashMap<String, Double>> vecList) {
//		Scanner sc = new Scanner(System.in);
//		System.out.print("�ڻ��� ���絵�� �ľ��� ���ϸ��� �Է��� �ּ���. : ");
//		String file_name = sc.next();
		
		rankSorter rs = new rankSorter();
		Set<String> keyList_f = vecList.keySet();
		HashMap<String, HashMap<String, Double>> cs = new HashMap<>();

		for (String out: keyList_f) {
			HashMap<String, Double> cs_i = new HashMap<>();
			for (String in: keyList_f) {
				HashMap<String, Double> vector_1 = vecList.get(out);
				HashMap<String, Double> vector_2 = vecList.get(in);

				ArrayList<ArrayList<String>> filteredVectorKeys = rs.sortHSbyValue(vector_1, vector_2);
				ArrayList<String> top5keyList1 = filteredVectorKeys.get(0);
				ArrayList<String> top5keyList2 = filteredVectorKeys.get(1);
				
				HashMap<String, Double> filteredVec1 = new HashMap<>();
				HashMap<String, Double> filteredVec2 = new HashMap<>(); 
				for(String key:top5keyList1)
					filteredVec1.put(key, vector_1.get(key));
				for(String key:top5keyList2)
					filteredVec2.put(key, vector_2.get(key));
				
				vector_1 = unionVec_TFIDF(filteredVec1, filteredVec2).get(0);
				vector_2 = unionVec_TFIDF(filteredVec1, filteredVec2).get(1);
				
				Set<String> keyList_c = vector_1.keySet();

				double sigma0=0.0; double sigma1=0.0; double sigma2=0.0;
				for (String key: keyList_c) {
					sigma0 += vector_1.get(key) * vector_2.get(key);
					sigma1 += Math.pow(vector_1.get(key), 2);
					sigma2 += Math.pow(vector_2.get(key), 2);
				}
				sigma1 = Math.sqrt(sigma1);
				sigma2 = Math.sqrt(sigma2);
				double answer = sigma0 / (sigma1*sigma2);
				
				cs_i.put(in, answer);
			}
			cs.put(out, cs_i);
		}
		System.out.println(cs);
		return cs;
	}
}

