package Functions.fileGetter;

import java.io.File;

public class Getter {
	// file 01~07
	public static File[] get_file() {
		String path = ".\\src\\�����˻�_��������\\";
		File dir = new File(path);
		File[] fileList = dir.listFiles();
		
		for(File file: fileList) {
			if(file.isFile()) {
				String fileName = file.getName();
//				System.out.println(fileName);
			}
		}
		
	    return fileList;
	}	
	
	// file 08~10
	public static File[] get_file2() {
		String path = ".\\src\\�����˻�_��������01\\";
		File dir = new File(path);
		File[] fileList = dir.listFiles();
		
		for(File file: fileList) {
			if(file.isFile()) {
				String fileName = file.getName();
//				System.out.println(fileName);
			}
		}
		
	    return fileList;
	}	
	
	// file 01~10
	public static File[] conbine() {
		File[] fileList1 = get_file();
		File[] fileList2 = get_file2();
		
        File[] fileList  = new File[fileList1.length + fileList2.length];

        System.arraycopy(fileList1, 0, fileList, 0, fileList1.length);
        System.arraycopy(fileList2, 0, fileList, fileList1.length, fileList2.length);
        
        return fileList;
	}
}
