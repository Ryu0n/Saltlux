package Functions.fileGetter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Reader {
	// for Character
	public static ArrayList<Character> reading(File file) {
		ArrayList<Character> dish = new ArrayList<>();
		try {
	        FileReader filereader = new FileReader(file);
	        int singleCh = 0;
	        while((singleCh = filereader.read()) != -1){
	        	if((char)singleCh!=' ') {
		        	dish.add((char)singleCh);
	        	}
	        }
	        filereader.close();
		}
		catch(FileNotFoundException e) {
			
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return dish;
	}
	
	// for String
	public static ArrayList<String> reading_str(File file) {
		ArrayList<String> dish = new ArrayList<>();

		try {
	        FileReader filereader = new FileReader(file);
	        BufferedReader bufReader = new BufferedReader(filereader);
	        String line = "";
	        while((line = bufReader.readLine()) != null){
	            String[] str_ar = line.split(" ");
	            for (String s: str_ar) {
	            	dish.add(s);
	            }
	        }
		}
		catch(FileNotFoundException e) {
			
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return dish;
	}
}
