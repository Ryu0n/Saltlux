package Functions.TF_IDF;

import java.util.ArrayList;

public class cal_TFIDF {
	// for Character TF_List
	public static double get_TF(char input_ch, ArrayList<Character> file_detail) {
		int cnt=0;
		int size=file_detail.size();
		for (int i=0; i<size; i++) {
			if(input_ch==file_detail.get(i)) {
				cnt++;
			}
		}
		
		double TF = (double)cnt/size;
		return TF;
	}

	// for String TF_List
	public static double get_TF(String input_ch, ArrayList<String> file_detail) {
		int cnt=0;
		int size=file_detail.size();
		for (int i=0; i<size; i++) {
			if(input_ch.equals(file_detail.get(i))) {
				cnt++;
			}
		}
		
		double TF = (double)cnt/size;
		return TF;
	}
	
	
	
	// for IDF score (considering all files)
	public static double get_IDF(int in_counter, int num_files) {
		if(in_counter!=0) {
			double IDF = Math.log(1+(double)num_files/in_counter);
			return IDF;
		} else {
			return 0.0;
		}
		
	}
}
