package Functions.Sorter;

import java.util.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class rankSorter {
	// for Ex02
	public static ArrayList<Character> sortHSbyValue(HashMap<Character, Integer> target) {
		ArrayList<Map.Entry<Character, Integer>> k = new ArrayList<>(target.entrySet());
		Collections.sort(k, new Comparator<Map.Entry<Character, Integer>>() {
			@Override
			public int compare(Entry<Character, Integer> o1, Entry<Character, Integer> o2) {
				int comparison = (o2.getValue() > o1.getValue() ? 1 : -1);
	            if(o2.getValue()==(o1.getValue())) comparison = o1.getKey().compareTo(o2.getKey());
	            return   comparison;
			}
		});
		
		ArrayList<Character> top5KeyList = new ArrayList<>();
		for(int i=0; i<5; i++) {
			top5KeyList.add(k.get(i).getKey());
		}
		
		return top5KeyList;
	}

	// for Ex04
	public static ArrayList<String> sortHSbyValue_double(HashMap<String, Double> target) {
		
		ArrayList<Map.Entry<String, Double>> k = new ArrayList<>(target.entrySet());
		Collections.sort(k, new Comparator<Map.Entry<String, Double>>() {
			@Override
			public int compare(Entry<String, Double> o1, Entry<String, Double> o2) {
				int comparison = (o2.getValue() > o1.getValue() ? 1 : -1);
	            if(o2.getValue()==(o1.getValue())) comparison = o1.getKey().compareTo(o2.getKey());
	            return   comparison;
			}
		});
		
		
		ArrayList<String> top5KeyList = new ArrayList<>();
		for(int i=0; i<5; i++) {
			top5KeyList.add(k.get(i).getKey());
		}
		
		return top5KeyList;
	}

	// for Ex05
	public static ArrayList<String> sortHSbyValue_str(HashMap<String, Integer> target) {
		ArrayList<Map.Entry<String, Integer>> k = new ArrayList<>(target.entrySet());
		Collections.sort(k, new Comparator<Map.Entry<String, Integer>>() {
			@Override
			public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
				int comparison = (o2.getValue() > o1.getValue() ? 1 : -1);
	            if(o2.getValue()==(o1.getValue())) comparison = o1.getKey().compareTo(o2.getKey());
	            return   comparison;
			}
		});
		
		ArrayList<String> top5KeyList = new ArrayList<>();
		for(int i=0; i<5; i++) {
			top5KeyList.add(k.get(i).getKey());
		}
		
		return top5KeyList;
	}
	
	
	
	public static ArrayList<ArrayList<String>> sortHSbyValue(HashMap<String, Double> vector_1, HashMap<String, Double> vector_2){
		ArrayList<ArrayList<String>> filteredVectorKeys = new ArrayList<>();
		
		ArrayList<String> top5keyList1 = sortHSbyValue_double(vector_1);
		ArrayList<String> top5keyList2 = sortHSbyValue_double(vector_2);
		
		filteredVectorKeys.add(top5keyList1);
		filteredVectorKeys.add(top5keyList2);
		
		return filteredVectorKeys;
	}
}
