package Ex02;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.Scanner;
import java.util.Set;

import Ex01.Ex01;
import Functions.Sorter.rankSorter;
import Functions.fileGetter.Getter;
import Functions.fileGetter.Reader;
import Functions.initializer.matrixInitializer;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

public class Ex02 {
	
	// for Ex04
	public Ex02() {
//		execute();
	}
	
	// for Ex05
	public Ex02(String input_ch, int window_size) {
		execute_5(input_ch, window_size);
	}
	
	
	
	public static void main(String[] args) {
			execute();
		}
	
	
	
	// for Ex02
	public static void execute() {
		Getter getter = new Getter();
		Reader reader = new Reader();
		matrixInitializer initializer = new matrixInitializer();
		rankSorter sorter = new rankSorter();
		
		Scanner sc = new Scanner(System.in); // ��ĳ�� ��ü ���� �� ���۷��� ��ȯ
		
		System.out.print("���ڸ� �Է��� �ּ���. : ");
		char input_ch = sc.next().charAt(0); // ���� �Է�
		
		System.out.print("������ ����� �Է��� �ּ��� : ");
		int window_size = sc.nextInt();      // ������ ������ �Է�
		
		File[] fileList = getter.get_file(); // ���� ���۷��� ��ȯ

		ArrayList<HashMap<Character, HashMap<Character, Integer>>> matList = new ArrayList<>();
		
		for (File file: fileList) { // �� ���� ��ȸ
				ArrayList<Character> file_detail = reader.reading(file);
				HashMap<Character, HashMap<Character, Integer>> matrix = initializer.initialize_matrix(window_size, file_detail);
				System.out.println(matrix.get(input_ch));
				matList.add(matrix);
			}
		
		HashMap<Character, HashMap<Character, Integer>> sumage = calc(matList);
		HashMap<Character, Integer> target = sumage.get(input_ch);
		ArrayList<Character> top5keyList = sorter.sortHSbyValue(target);
		
		for(char key:top5keyList) {
			System.out.print(key);
			System.out.println(" : " + target.get(key));
		}	
	}
	
	// for Ex05-02
	public static void execute_5(String input_ch, int window_size) {
		Getter getter = new Getter();
		Reader reader = new Reader();
		matrixInitializer initializer = new matrixInitializer();
		rankSorter sorter = new rankSorter();
		
		File[] fileList = getter.conbine(); // ���� ���۷��� ��ȯ

		ArrayList<HashMap<String, HashMap<String, Integer>>> matList = new ArrayList<>();
		
		for (File file: fileList) { // �� ���� ��ȸ
				ArrayList<String> file_detail = reader.reading_str(file);
				HashMap<String, HashMap<String, Integer>> matrix = initializer.initialize_str_matrix(window_size, file_detail);
				System.out.println(matrix.get(input_ch));
				matList.add(matrix);
			}
		
		HashMap<String, HashMap<String, Integer>> sumage = calc_str(matList);
		HashMap<String, Integer> target = sumage.get(input_ch);
		ArrayList<String> top5keyList = sorter.sortHSbyValue_str(target);
		
		for(String key:top5keyList) {
			System.out.print(key);
			System.out.println(" : " + target.get(key));
		}
	}
	
	// for Ex05-04
	public static void execute_5(String input_ch, int window_size, int path) {
		Getter getter = new Getter();
		Reader reader = new Reader();
		matrixInitializer initializer = new matrixInitializer();
		rankSorter sorter = new rankSorter();
		
		File[] fileList = null;
		if(path==1) {
			fileList = getter.get_file();
		} else if(path==2) {
			fileList = getter.get_file2();
		} // ���� ���۷��� ��ȯ

		ArrayList<HashMap<String, HashMap<String, Integer>>> matList = new ArrayList<>();
		
		for (File file: fileList) { // �� ���� ��ȸ
				ArrayList<String> file_detail = reader.reading_str(file);
				HashMap<String, HashMap<String, Integer>> matrix = initializer.initialize_str_matrix(window_size, file_detail);
				System.out.println(matrix.get(input_ch));
				matList.add(matrix);
			}
		
		HashMap<String, HashMap<String, Integer>> sumage = calc_str(matList);
		HashMap<String, Integer> target = sumage.get(input_ch);
		ArrayList<String> top5keyList = sorter.sortHSbyValue_str(target);
		
		for(String key:top5keyList) {
			System.out.print(key);
			System.out.println(" : " + target.get(key));
		}
	}

	
	// for Character
	public static HashMap<Character, HashMap<Character, Integer>> calc(ArrayList<HashMap<Character, HashMap<Character, Integer>>> matList){
		HashMap<Character, HashMap<Character, Integer>> answer = new HashMap<>();

		Set<Character> keyList = new HashSet<>();
		
		for(HashMap hm : matList) {
			Set<Character> s = hm.keySet();
			for(char key : s) {
				keyList.add(key);
			}
		}
		
		// zero base initialize
		for(char key_o: keyList) {
			HashMap<Character, Integer> row = new HashMap<>();
			for(char key_i: keyList) {
				row.put(key_i, 0);
			}
			answer.put(key_o, row);
		}
		
		System.out.println("new");
		System.out.println(answer);
		
		
		// accumulate
		for(int i=0; i<matList.size(); i++) { // ��� ����Ʈ ��ȸ
			HashMap<Character, HashMap<Character, Integer>> hs_i = matList.get(i);
			Set<Character> keyList_o = hs_i.keySet();
			for(char key_o: keyList_o) { // �ؽø� ��ȸ
				HashMap<Character, Integer> hs_j = hs_i.get(key_o);
				Set<Character> keyList_i = hs_j.keySet();
				HashMap<Character, Integer> row = answer.get(key_o);
				for(char key_i: keyList_i) {
					row.put(key_i, row.get(key_i) + matList.get(i).get(key_o).get(key_i));
				}
				answer.put(key_o, row);
			}
		}
		return answer;
	}
	
	// for String
	public static HashMap<String, HashMap<String, Integer>> calc_str(ArrayList<HashMap<String, HashMap<String, Integer>>> matList){
		HashMap<String, HashMap<String, Integer>> answer = new HashMap<>();
		
		Set<String> keyList = new HashSet<>();
		
		for(HashMap hm : matList) {
			Set<String> s = hm.keySet();
			for(String key : s) {
				keyList.add(key);
			}
		}
		
		// zero base initialize
		for(String key_o: keyList) {
			HashMap<String, Integer> row = new HashMap<>();
			for(String key_i: keyList) {
				row.put(key_i, 0);
			}
			answer.put(key_o, row);
		}		
		
		// accumulate
		for(int i=0; i<matList.size(); i++) { // ��� ����Ʈ ��ȸ
			HashMap<String, HashMap<String, Integer>> hs_i = matList.get(i);
			Set<String> keyList_o = hs_i.keySet();
			for(String key_o: keyList_o) { // �ؽø� ��ȸ
				HashMap<String, Integer> hs_j = hs_i.get(key_o);
				Set<String> keyList_i = hs_j.keySet();
				HashMap<String, Integer> row = answer.get(key_o);
				for(String key_i: keyList_i) {
					row.put(key_i, row.get(key_i) + matList.get(i).get(key_o).get(key_i));
				}
				answer.put(key_o, row);
			}
		}	
		return answer;
	}

}



