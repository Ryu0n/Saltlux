package Ex03;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
//import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import Functions.CosineSimiliarity.CosineSimiliarity;
import Functions.Sorter.rankSorter;
import Functions.fileGetter.Getter;
import Functions.fileGetter.Reader;
import Functions.initializer.vectorInitializer;

public class Ex03 {
	// for Ex05
	public Ex03() {
		execute_5();
	}

	public static void main(String[] args) {
		execute();
	}
	
	// for Ex03
	public static void execute() {
		Getter getter = new Getter();
		Reader reader = new Reader();
		vectorInitializer initializer = new vectorInitializer();
		CosineSimiliarity cs_cal = new CosineSimiliarity();
		Scanner sc = new Scanner(System.in); // ��ĳ�� ��ü ���� �� ���۷��� ��ȯ
		
		System.out.print("�ڻ��� ���絵�� �ľ��� ���ϸ��� �Է����ּ���. : ");
		String doc_name = sc.next(); // ���� �Է�
		
		File[] fileList = getter.get_file(); // ���� ���۷��� ��ȯ
		ArrayList<HashMap<String, Double>> vectorList = new ArrayList<>();
		
		for (File file: fileList) { // �� ���� ��ȸ
			ArrayList<String> file_detail = reader.reading_str(file);
			HashSet<String> keyList = initializer.withoutDuplicate(file_detail);
			HashMap<String, Double> vector = initializer.initializeVec_str(file_detail);
			vectorList.add(vector);
		}
		HashMap<String, HashMap<String, Double>> cs = cs_cal.cosineSimilarity(fileList, vectorList);
		System.out.println(cs);
		System.out.println("\n" + doc_name + "'s consine similiarity is..");
//		System.out.println(cs.get(doc_name));
		ArrayList<String> keyList = rankSorter.sortHSbyValue_double(cs.get(doc_name));
		for(String key : keyList){
			System.out.print(key + " : ");
			System.out.println(cs.get(doc_name).get(key));
		}
	}

	// for Ex05-03
	public static void execute_5() {
		Getter getter = new Getter();
		Reader reader = new Reader();
		vectorInitializer initializer = new vectorInitializer();
		CosineSimiliarity cs_cal = new CosineSimiliarity();
		Scanner sc = new Scanner(System.in); // ��ĳ�� ��ü ���� �� ���۷��� ��ȯ
		
		System.out.print("�ڻ��� ���絵�� �ľ��� ���ϸ��� �Է����ּ���. : ");
		String doc_name = sc.next(); // ���� �Է�
		
		File[] fileList = getter.conbine(); // ���� ���۷��� ��ȯ
		ArrayList<HashMap<String, Double>> vectorList = new ArrayList<>();
		
		for (File file: fileList) { // �� ���� ��ȸ
			ArrayList<String> file_detail = reader.reading_str(file);
			HashSet<String> keyList = initializer.withoutDuplicate(file_detail);
			HashMap<String, Double> vector = initializer.initializeVec_str(file_detail);
			vectorList.add(vector);
		}
		HashMap<String, HashMap<String, Double>> cs = cs_cal.cosineSimilarity(fileList, vectorList);
		System.out.println(cs);
		System.out.println("\n" + doc_name + "'s consine similiarity is..");
//		System.out.println(cs.get(doc_name));
		ArrayList<String> keyList = rankSorter.sortHSbyValue_double(cs.get(doc_name));
		for(String key : keyList){
			System.out.print(key + " : ");
			System.out.println(cs.get(doc_name).get(key));
		}
	}
	
//	// for Ex05-04
//	public static void execute_5(int path) {
//		Getter getter = new Getter();
//		Reader reader = new Reader();
//		vectorInitializer initializer = new vectorInitializer();
//		CosineSimiliarity cs_cal = new CosineSimiliarity();
//		Scanner sc = new Scanner(System.in); // ��ĳ�� ��ü ���� �� ���۷��� ��ȯ
//		
//		System.out.print("�ڻ��� ���絵�� �ľ��� ���ϸ��� �Է����ּ���. : ");
//		String doc_name = sc.next(); // ���� �Է�
//		
//		File[] fileList = null;
//		if(path==1) {
//			fileList = getter.get_file();
//		} else if(path==2) {
//			fileList = getter.get_file2();
//		} // ���� ���۷��� ��ȯ
//		ArrayList<HashMap<String, Double>> vectorList = new ArrayList<>();
//		
//		for (File file: fileList) { // �� ���� ��ȸ
//			ArrayList<String> file_detail = reader.reading_str(file);
//			HashSet<String> keyList = initializer.withoutDuplicate(file_detail);
//			HashMap<String, Double> vector = initializer.initializeVec_str(file_detail);
//			vectorList.add(vector);
//		}
//		HashMap<String, HashMap<String, Double>> cs = cs_cal.cosineSimilarity(vectorList);
//		System.out.println(cs);
//		System.out.println("\n" + doc_name + "'s consine similiarity is..");
//		System.out.println(cs.get(doc_name));
//	}
}